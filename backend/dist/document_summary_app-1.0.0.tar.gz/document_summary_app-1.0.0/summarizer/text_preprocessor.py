# summarizer/text_preprocessor.py

def preprocess_text(text):
    return text.replace('\n', ' ').strip()
